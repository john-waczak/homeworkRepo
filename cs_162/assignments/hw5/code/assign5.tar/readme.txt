John Waczak

This program demonstrates the uses of the Linked_List class by allowing you to add to list, sort, and count the number of primes.


******EXTRA CREDIT*******

1. I implemented the program using a template class. You can select either signed or unsigned int upon running the program.

NOTE: the prime number check works for 4294963943. It just takes a while.

2. I implemented sort_descending using the SelectionSort algorithm.
