function y = fixed_f2(x)
    y = 1-x/2+x^2/6; 
end

