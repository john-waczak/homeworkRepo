function y = f2(x)
    y = (1-exp(-x))/x; 
end

