function E = relative(xT, xA)
    E = abs(xT-xA)/abs(xT);
end

