function y = f1(x)
    y = (sqrt(4+x)-2)/x; 
end

