function y = fixed_f1(x)
    y = 1/(sqrt(4+x)+2); 
end

